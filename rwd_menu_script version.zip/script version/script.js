let menuOptions = document.getElementById("menu");
let optionList = document.getElementsByClassName("option_style");
let linkList = document.getElementsByClassName("link_list");
let linkListPos = document.getElementsByTagName("linkList li")
console.log(optionList);

let clickCounter = 1;

const scrollDown = () =>
{  
    if(clickCounter % 2 == 0 )
    {
        menuOptions.classList.remove("menu_style_scrolled");
        menuOptions.classList.add("menu_style_basic");
    }
    else
    {
        menuOptions.classList.remove("menu_style_basic");
        menuOptions.classList.add("menu_style_scrolled");
    }   

    clickCounter = clickCounter+1;

    for(i=0; i<optionList.length; i++)
    {
        optionList[i].classList.toggle("option_style_mobile");   
    }

    for(i=0; i<linkList.length; i++)
    {
        linkList[i].classList.toggle("link_list_mobile");
    }
}

const changeMenu = () =>
{
    let screenWidth = window.innerWidth;  
    let i;    
    console.log(screenWidth);
    console.log(clickCounter);

    if(screenWidth > 550 && clickCounter % 2 == 0 )
    {
        menuOptions.classList.remove("menu_style_scrolled");
        menuOptions.classList.add("menu_style_basic");

        for(i=0; i<optionList.length; i++)
        {
            optionList[i].classList.remove("option_style_mobile");   
        }

        for(i=0; i<linkList.length; i++)
        {
            linkList[i].classList.remove("link_list_mobile");
        }

        clickCounter = clickCounter + 1;
    }
}